import pathlib

__all__ = [
    "LOCAL_DIRECTORY"
]


# Local Directory Current Path
LOCAL_DIRECTORY = pathlib.Path().resolve()