
# Module Documentation
"""
Database Module:
    This module is used to manipulate database on an OOO level so then others who might not know SQL can work with databases easily.
"""


# Import Modules
import os, sqlite3, pandas
from .functions import checkType

__all__ = [
    "Column"
    , "Table"
    , "Database"
]

# Column Object for SQLite Database
class Column:
    def __init__(self, name:str, dtype:type, **kwargs) -> None:
        """Column for SQLite Table Database

        :param name: Column Name
        :type name: str
        :param dtype: DataType of Column
        :type dtype: type
        """
        
        # Column Name 
        self._name = name
        
        # Column Data Type
        self._dtype = dtype
        
        # Add Keyword Arguments
        self.__dict__.update(kwargs)
        
    @staticmethod
    def _convertType(type:type)-> str:
        """Convert Type into SQL Datatype

        :param type: Type in Python you want to Convert
        :type type: type
        :return: SQL Datatype
        :rtype: str
        """
        
        # Convert Type to SQLite Datatype
        dictionary = {int:"INTEGER",float:"REAL",str:"TEXT",bool:"BOOLEAN"}
        
        return dictionary.get(type)

    @property
    def sql(self) -> str:
        """SQL Code

        :return: SQL Code to create Column
        :rtype: str
        """
        
        # SQL code for Column Creation
        return f"{self.name} {self._convertType(self._dtype)}"

    @property
    def name(self) -> str:
        return self._name
    
# Table Object for SQLite Database
class Table:
    def __init__(self, name:str, connection:sqlite3.Connection, columns:list[Column] = None, **kwargs) -> None:
        
        # Name, Connection, & Columns
        self._name = name
        self._connection = connection
        self._columns = columns
        
        # Checking Existance of the Table
        if not self.exist():
            if columns is None: raise ValueError("Table Does Not Exists And Requires `columns` parameter to be filled")

            self._create()
            
        # Pass on Keyword Arguments
        self.__dict__.update(kwargs)
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection
    
    @property
    def columns(self) -> list[Column]:
        return self._columns
    
    def exist(self) -> bool:
            
        # Checks Existance of Table
        return self._connection.execute(f"SELECT name FROM sqlite_master WHERE type ='table' AND name ='{self._name}';").fetchone() is not None
          
    def _create(self) -> None:
        
        if not Table.exist(self._name, self._connection):
    
            # Creates the SQL Code
            sql = f"CREATE TABLE {self._name} ("
            
            for column in self._columns:
                if column == self._columns[-1]:
                    sql += column.sql
                else:
                    sql += f"{column.sql}, "
                
            sql += ") ;"
            # Creating Tables
            self._connection.execute(sql)
            self._connection.commit()
        
    def delete(self, name:str = None, connection:sqlite3.Connection = None) -> None:
        
        # Checking the existance of the Table in the Database
        if Table.exist(name, connection): 
        
            # Deleting the Table
            connection.execute(f"DROP TABLE {name};")
            connection.commit()
        
    def update(self, df:pandas.DataFrame) -> None:
        """Changes DataFrame to Database Table

        :param df: DataFrame to Update Database
        :type df: DataFrame
        """
        
        # Turns DataFrame into 
        df.to_sql(self._name,self._connection, if_exists='replace', index = False)
   
    @property
    def data(self) -> pandas.DataFrame:
        """Data DataFrame in the Table Database

        :return: Table Data
        :rtype: DataFrame
        """
        # Dataframe stored in Database Table
        return pandas.read_sql_query(f"SELECT * FROM {self._name}", self._connection)

# Database Object for SQLite Database
class Database:
    def __init__(self, directory:str, **kwargs) -> None:
        
        # Check Directory Type
        if not checkType({directory:str}): raise TypeError("Directory is not a `str`")
        
        # Database Directory
        self._directory = directory
        
        # Create Database if does not Exist
        if not self.exist(): self.create()
        
        # Database Connection
        self._connection = sqlite3.connect(directory,timeout=8)
        
        # Tables 
        self.tables = self._getTables()
        
        # Pass on Keyword Arguments
        self.__dict__.update(kwargs)
      
    @property
    def directory(self) -> str:
        return self._directory  
         
    def exist(self) -> bool:
        
        # Checks to see if Directory is a .db file
        if self.directory[-3:] != ".db": raise ValueError("Not a .db file directory")
        
        # Checks Directory Existance
        return os.path.exists(self.directory)
    
    def create(self) -> None:
        
        # Checks to see if the Database already exists
        if not self.exist():
        
            # Creation of the Database File
            with open(self.directory,"x") as file:
                pass
    
    def delete(self) -> None:
        
        # Checks to see if the Database already exists
        if self.exist(): 
            os.remove(self.directory)
            self._directory = None
            self._connection = None
    
    def addTable(self, name:str, columns:list[Column]) -> Table:
        
        # Check Directory Type
        if not checkType({name:str, columns: list[Column]}): raise TypeError("Parameters not correct Type")
        
        t = Table( name, self._connection, columns)
        self.tables.append(t)
        
        return t
      
    def removeTable(self, name:str) -> None:
        if self.tables.get(name):
            self.tables.remove(name)
        else:
            raise ValueError("Table Does Not Exist")
             
    def _getTables(self) -> list[Table]:
        
        # Table Names
        tableNames = [name[0] for name in self._connection.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
        
        # Create a Table Objects
        return [Table(name, self._connection) for name in tableNames]
         