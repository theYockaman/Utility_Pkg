from setuptools import setup, find_packages


setup(
    name = "utils"
    , version = "0.0.1"
    , author = "Nathan Yockey"
    , description = "Utils Package is universal across building of other Python Projects"
    , packages = find_packages()
)