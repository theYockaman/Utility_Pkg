# Utility_Pkg

File.py
: Creates Object to easily work with Files