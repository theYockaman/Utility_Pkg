# Utility_Pkg

## Database

### Column

### Database

### DatabaseExistsError

### DatabaseNotFoundError

### Table

### TableExistsError

### TableNotFoundError

## File

### CSV

### File

### Folder

### JSON

### LOCAL_DIRECTORY

### TXT

## Functions

### printSyntax

### printTraceback

### checkType

### Duration

## Math

### sigmoid

### average

## Words