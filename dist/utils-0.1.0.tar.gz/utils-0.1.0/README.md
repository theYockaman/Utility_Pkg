# Utility_Pkg
Basic idea a simple utilities package to help everyday python programming and make it easier.

## File

### CSV

### File

### Folder

### JSON

### LOCAL_DIRECTORY

### TXT

## Functions

### printSyntax

### printTraceback

### Duration

## Math

### sigmoid

### average

## Words