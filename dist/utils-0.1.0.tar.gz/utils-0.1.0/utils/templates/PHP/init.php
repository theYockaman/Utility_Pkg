<?php

// Creation of the Session
session_start();

// Default Set Session Variables




?>