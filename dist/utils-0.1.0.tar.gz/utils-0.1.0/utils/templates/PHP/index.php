<?php require_once 'PHP/init.php'; ?>

<!DOCTYPE html>
<html>
    <head>

        <!-- Title of the Page -->
        <title>Page Title</title>

        <!-- Tab Icon -->
        <link rel = "icon" href = "#">

        <!-- Link to CSS Files -->
        <link rel = "stylesheet" href = "CSS/reset.css">

        <!-- Link to JS Files -->
        <script src = "JS/jquery.js"></script>
        <script src = "JS/main.js"></script>

    </head>
    <body>
        <main>

        </main>
    </body>
</html>