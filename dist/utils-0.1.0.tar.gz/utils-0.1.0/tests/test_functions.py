from unittest import TestCase
import unittest
from utils import functions
from time import sleep

class TestFunctions(TestCase):
    
    def test_printSyntax(self):
        
        # Print Syntax
        functions.printSyntax("Syntax")
        
        # Print Syntax
        functions.printSyntax("Syntax", False)
        
    def test_duration(self):
        
        d = functions.Duration()
        sleep(5)
        d.end()
        
if __name__ == '__main__':
    unittest.main()