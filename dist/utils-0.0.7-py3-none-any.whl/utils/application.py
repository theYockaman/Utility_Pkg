from .file import *


def createWebsite(name:str) -> None:
    index = File('index.html','html')
    
    
    
    
    